#!/bin/bash

echo "Vérification des prérequis système pour FHIRHub..."
node check_system.js